from django.db import models


class Role(models.Model):
    name = models.CharField(max_length=32)
    

class User(models.Model):
    # nid = models.AutoField(primary_key=True)    .pk
    name = models.CharField(max_length=32)
    age = models.IntegerField()
    role = models.ForeignKey('Role', null=True, blank=True)
