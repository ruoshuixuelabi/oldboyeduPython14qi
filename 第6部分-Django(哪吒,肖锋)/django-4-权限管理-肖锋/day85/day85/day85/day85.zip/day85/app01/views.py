from django.shortcuts import render, HttpResponse
from app01 import models
from django.views.decorators.cache import cache_page
import time, datetime
import pickle
from my_signals import pizza_done


# @cache_page(15 * 60)
def user_list(request):
    now = time.time()
    users = models.User.objects.all()
    return render(request, 'user_list.html', {'users': users, 'now': now})


def timer(request):
    now = datetime.datetime.now()
    return HttpResponse(now)


from django.core import serializers
import json


def get_value(request):
    # queryset [  ]
    users = models.User.objects.all().values('pk', 'name', 'age')
    users = models.User.objects.create()
    # ret = serializers.serialize('json', users)
    
    return HttpResponse(json.dumps(list(users)))


def save_data(request):
    # models.User.objects.create(name='alex', age=73)
    # obj = models.User.objects.filter(id=1).first()
    #
    # obj.name = 'egon'
    # obj.save()pizza_done.send(sender='seven', a=123, )
    
    return HttpResponse('保存成功')


def users(request):
    # all_users = models.User.objects.all().select_related('role')
    # for user in all_users:
    #     # print(user['name'], user['age'], user['role__name'])
    #     print(user.name, user.age, user.role.name)
    #
    # all_users = models.User.objects.all().prefetch_related('role')
    # for user in all_users:
    #     # print(user['name'], user['age'], user['role__name'])
    #     print(user.name, user.age, user.role.name)
    
    all_users = models.User.objects.all().only('name', 'age')
    for user in all_users:
        # print(user['name'], user['age'], user['role__name'])
        print(user.name, user.age)
    
    return HttpResponse('OK')


from PIL import Image, ImageDraw, ImageFont
import random


def random_color():
    return random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)


def v_code(request):
    img_obj = Image.new('RGB', (250, 35), random_color())
    
    # 在该图片对象上生成一个画笔对象
    draw_obj = ImageDraw.Draw(img_obj)
    
    font_obj = ImageFont.truetype('static/font/kumo.ttf', 28)
    
    temp = []
    for i in range(5):
        l = chr(random.randint(97, 122))  # 小写字母
        b = chr(random.randint(65, 90))  # 大写字母
        n = str(random.randint(0, 9))
        
        t = random.choice([l, b, n])
        temp.append(t)
        
        draw_obj.text((i * 40 + 35, 0), t, fill=random_color(), font=font_obj)
    
    from io import BytesIO
    f1 = BytesIO()
    img_obj.save(f1, format="PNG")
    img_data = f1.getvalue()
    
    return HttpResponse(img_data, content_type='image/png')
