from django.conf.urls import url, include

from crm import views

urlpatterns = [
    # 公户
    # url(r'customer_list', views.customer_list, name='customer'),
    url(r'customer_list/', views.CustomerList.as_view(), name='customer'),
    # 私户
    # url(r'my_customer', views.customer_list, name='my_customer'),
    url(r'my_customer/', views.CustomerList.as_view(), name='my_customer'),
    # # 增加客户
    # url(r'customer/add/', views.add_customer, name='add_customer'),
    # # 编辑客户
    # url(r'customer/edit/(\d+)', views.edit_customer, name='edit_customer')
    
    # 增加客户
    url(r'customer/add/', views.customer, name='add_customer'),
    # 编辑客户
    url(r'customer/edit/(\d+)', views.customer, name='edit_customer'),
    
    # 展示跟进记录
    url(r'consult_record_list/(?P<customer_id>\d+)', views.ConsultRecord.as_view(), name='consult_record'),
    # 添加跟进记录
    url(r'consult_record/add/', views.consult_record, name='add_consult_record'),
    # 编辑跟进记录
    url(r'consult_record/edit/(\d+)/', views.consult_record, name='edit_consult_record'),
    # 展示报名记录
    url(r'enrollment_list/(?P<customer_id>\d+)', views.EnrollmentList.as_view(), name='enrollment'),
    # 添加报名记录
    url(r'enrollment/add/(?P<customer_id>\d+)', views.enrollment, name='add_enrollment'),
    # 编辑报名记录
    url(r'enrollment/edit/(?P<edit_id>\d+)', views.enrollment, name='edit_enrollment'),
    
]
