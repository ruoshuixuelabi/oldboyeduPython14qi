from django.test import TestCase

# Create your tests here.


#
# class  Animal(object):
#     name="egon"
#     def __init__(self,name):
#         self.name=name
#
#     def running(self):
#         print("%s is running..."%self.name)
#
#
# class Dog(Animal):
#
#     def sleeping(self):
#         print("%s is sleeping")
#
#
#
# alex=Dog("alex")
#
# alex.running()



##########################################



# class Animal(object):
#     def __init__(self,name,age):
#         self.name=name
#         self.age=age
#
#
# alex=Animal("alex",123)


# print(alex.name)
# print(alex.age)


# field="name"

# print(alex.field)

# 反射

# val=getattr(alex,field)
# print(val)
###########################################################

class Animal(object):
    def __init__(self,name,age):
        self.name=name
        self.age=age

    def jump(self):
        print("B jumping....")


# def jump(x):
#     print(x)
#     print("A jumping....")



# jump("123")
# alex=Animal('alex',32)
# alex.jump()


# Animal.jump(123)





































