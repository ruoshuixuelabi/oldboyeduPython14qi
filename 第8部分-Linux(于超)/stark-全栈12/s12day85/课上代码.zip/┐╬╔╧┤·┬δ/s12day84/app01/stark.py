


print("app01...")

from stark.service.sites import site,ModelStark
from app01.models import *
from django.utils.safestring import mark_safe

class BookConfig(ModelStark):

    def edit(self,obj=None,is_header=False):
        if is_header:
            return "操作"
        else:
            return mark_safe("<a href='/stark/app01/book/%s/change/'>编辑</a>"%obj.pk)


    def delete(self,obj=None,is_header=False):
        if is_header:
            return "删除"
        return mark_safe("<a href='/stark/app01/book/%s/delete/'>删除</a>"%obj.pk)

    list_display=["title","price","publish","authors",edit,delete]

site.register(Book,BookConfig)
site.register(Publish)
site.register(Author)


print(site._registry)