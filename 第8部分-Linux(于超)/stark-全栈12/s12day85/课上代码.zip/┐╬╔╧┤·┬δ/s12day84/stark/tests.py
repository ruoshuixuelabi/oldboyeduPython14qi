from django.test import TestCase

# Create your tests here.

class Animal(object):pass

def foo():pass

print(callable(Animal))
