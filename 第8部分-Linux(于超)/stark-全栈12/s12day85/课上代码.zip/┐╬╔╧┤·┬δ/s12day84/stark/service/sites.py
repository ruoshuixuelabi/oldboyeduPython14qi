from django.conf.urls import url
from django.shortcuts import HttpResponse,render,redirect

class ModelStark(object):
    """
    默认配置类
    """
    list_display=["__str__"]

    def __init__(self,model):
        self.model=model


    def listview(self,request):

        print(self) # 当前访问模型表的配置类对象
        print(self.model) # 当前访问模型表

        data_list=self.model.objects.all()
        print("list_display:",self.list_display)  # ["title","price"]
        # 构建表头

        # header_list=["书籍名称","价格"]
        header_list=[]
        for field_or_func in self.list_display: # ["title","price","publish",edit]
            if callable(field_or_func):
                val=field_or_func(self,is_header=True)
            else:
                if field_or_func=="__str__":
                    val=self.model._meta.model_name
                else:
                    filed_obj=self.model._meta.get_field(field_or_func)
                    val=filed_obj.verbose_name
            header_list.append(val)

        # 构建数据表单部分

        new_data_list=[]

        for obj in data_list: # Queryset[book1,book2]
            temp=[]

            for field_or_func in self.list_display: #  # ["title","price","publish",edit]

                if callable(field_or_func):
                    val=field_or_func(self,obj)
                else:
                    #   获取字段对象
                    try:
                        from django.db.models.fields.related import ManyToManyField
                        field_obj=self.model._meta.get_field(field_or_func)
                        if isinstance(field_obj,ManyToManyField):
                             rel_data_list = getattr(obj, field_or_func).all()

                             l=[str(item) for item in rel_data_list]
                             val=",".join(l)
                        else:
                             val=getattr(obj,field_or_func)

                    except Exception as e:
                        val=getattr(obj,field_or_func)




                temp.append(val)  # ["python",122]

            new_data_list.append(temp) # [["python",122],["python",122]]







        '''
        data_list=self.model.objects.all()
        self.list_display
        
        

        
        data_list=[
            ["Python",122,"编辑"],
            ["linux",123，"编辑"],
        ]
        
        '''


        link="<a href=''>click</a>"
        s="hello"


        return render(request,"list_view.html",locals())

    def addview(self, request):

        return HttpResponse("addview")

    def changeview(self, request,id):

        return HttpResponse("changeview")

    def delview(self, request,id):

        return HttpResponse("delview")

    def get_urls(self):

        model_name=self.model._meta.model_name
        app_label=self.model._meta.app_label

        temp = [
            url(r"^$", self.listview,name="%s_%s_list"%(app_label,model_name)),
            url(r"add/$", self.addview,name="add"),
            url(r"(\d+)/change/$", self.changeview),
            url(r"(\d+)/delete/$", self.delview),

        ]
        return temp

    @property
    def urls(self):
        return self.get_urls(), None, None


class AdminSite(object):
    """
    stark组件的全局类
    """

    def __init__(self):
        self._registry = {}

    def register(self, model, admin_class=None):
        # 设置配置类
        if not admin_class:
            admin_class = ModelStark

        self._registry[model] = admin_class(model)


    def get_urls(self):
        temp = []

        # print("admin----->",admin.site._registry)

        for model, config_obj in self._registry.items():
            print("model", model) # Book
            print("config_obj", config_obj) # BookConfig(Book)
            model_name = model._meta.model_name # "book"
            app_label = model._meta.app_label   # "app01"

            temp.append(url(r"%s/%s/" %(app_label, model_name),config_obj.urls))

            '''
            temp=[
            
        
                #(1) url(r"app01/book/",BookConfig(Book).urls)
                #(2) url(r"app01/book/",(BookConfig(Book).get_urls(), None, None))
                #(3) url(r"app01/book/",([
                                                url(r"^$", BookConfig(Book).listview),
                                                url(r"add/$", BookConfig(Book).addview),
                                                url(r"(\d+)/change/$", BookConfig(Book).changeview),
                                                url(r"(\d+)/delete/$", BookConfig(Book).delview),
                                         ], None, None))
                                         
                ###########
                                         
                # url(r"app01/publish/",([
                                                url(r"^$", ModelStark(Publish).listview),
                                                url(r"add/$",  ModelStark(Publish).addview),
                                                url(r"(\d+)/change/$",  ModelStark(Publish).changeview),
                                                url(r"(\d+)/delete/$",  ModelStark(Publish).delview),
                                         ], None, None))
                                         
                                        
            
            ]
            
            
        
            '''

        return temp

    @property
    def urls(self):

        return self.get_urls(),None,None


site = AdminSite()






















