from django.conf.urls import url
from .views import CourseCategoryView, CourseView, CourseDetailView


urlpatterns = [
    # 课程分类的接口
    url(r'^category$', CourseCategoryView.as_view()),
    # 课程接口
    url(r'^$', CourseView.as_view()),
    # 课程详情接口
    url(r'^detail/(?P<id>\d+)$', CourseDetailView.as_view()),

]