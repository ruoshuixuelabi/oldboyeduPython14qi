<template>
    <div>
      <div>
         <p>{{course_detail.summary}}</p>
         <div>
            <p v-for="(price, index) in course_detail.price_policy" :key="index">{{price.valid_period}} ￥ {{price.price}}</p>
         </div>
          <p>{{course_detail.why_study}}</p>
      </div>

    </div>
</template>

<script>
    export default {
        name: "Brief",
        data(){
           return {
              course_detail: {}
           }
        },
        mounted(){
          // console.log(this.$route)
          let course_id = this.$route.params.id;
          // console.log(course_id)
          // 发送请求获取课程详情的所有数据
          let that = this;
          this.$axios.request({
              url: "http://127.0.0.1:8001/api/course/detail/" + course_id,
              method: "get"
          }).then(function (data) {
               console.log(data.data)
               if(data.status==200){
                  let  course_detail = data.data;
                  that.course_detail = course_detail;
                  let headerInfo = {
                      id: course_detail.id,
                      title: course_detail.title,
                      level: course_detail.level,
                      study_num: course_detail.study_num,
                      hours: course_detail.hours,
                      video_brief_link: course_detail.video_brief_link,
                      course_slogan: course_detail.course_slogan,
                  };
                  // 向仓库提价修改数据的事件
                  that.$store.commit("detailHeaderHandler", headerInfo)
               }
          })
        }
    }
</script>

<style scoped>

</style>
