<template>
    <div>
      <h1>这是课程详情组件</h1>
      <div style="border: solid 1px red; height: 300px">
            {{header_info}}
      </div>
      <router-link :to="{name: 'brief'}">课程概述</router-link>
      <router-link :to="{name: 'brief'}">课程章节</router-link>
      <router-link :to="{name: 'brief'}">课程评论</router-link>
      <router-link :to="{name: 'brief'}">常见问题</router-link>
      <router-view></router-view>
    </div>
</template>

<script>
    export default {
        computed: {
            header_info: function () {
                return this.$store.state.detail_header
            }
        }
    }
</script>

<style scoped>

</style>
