<template>
  <div id="app">
      <MyHeader></MyHeader>
      <router-view class="content"></router-view>
      <MyFooter></MyFooter>
  </div>
</template>

<script>
  import MyHeader from "./components/MyHeader"
  import MyFooter from "./components/MyFooter"
export default {
  name: 'App',
  components: {
      MyHeader,
      MyFooter
  }
}
</script>

<style>
.content{
    min-height: 600px;
}
</style>
