<template>
    <div>
      <h1>这是底部组件</h1>
    </div>
</template>

<script>
    export default {
        name: "MyFooter"
    }
</script>

<style scoped>

</style>
