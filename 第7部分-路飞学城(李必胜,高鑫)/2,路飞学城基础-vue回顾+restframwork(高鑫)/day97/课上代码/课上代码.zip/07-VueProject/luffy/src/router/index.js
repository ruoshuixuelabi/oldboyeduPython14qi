import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from "../components/header/Home"
import Course from "../components/header/Course"
import CourseDetail from "../components/header/CourseDetail"
import Brief from "../components/CourseChildren/Brief"
import Chapter from "../components/CourseChildren/Chapter"
import Comment from "../components/CourseChildren/Comment"
import OftenAskQuestion from "../components/CourseChildren/OftenAskQuestion"



Vue.use(VueRouter);

export default new VueRouter({
  mode: "history",
  routes: [
    {
      path: '/',
      name: "home",
      component: Home
    },
    {
      path: '/course',
      name: "course",
      component: Course
    },
    {
      path: "/course/detail/:id",
      redirect: {name: "brief"}   ,
      name: "detail",
      component: CourseDetail,
      children: [
        {
          path: "brief",
          name: "brief",
          component: Brief
        },
        {
          path: "chapter",
          component: Chapter
        },
        {
          path: "comment",
          component: Comment
        },
        {
          path: "often_ask_question",
          component: OftenAskQuestion
        }

      ]
    }
  ]
})
