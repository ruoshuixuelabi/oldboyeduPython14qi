<template>

</template>

<script>
    export default {
        name: "OftenAskQuestion"
    }
</script>

<style scoped>

</style>
