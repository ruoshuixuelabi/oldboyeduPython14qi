<template>
    <div>
        <h2>我是子组件{{getCount}} {{ title }}-- {{msg}}---{{ name}}</h2>
        
    </div>
</template>

<script>
    export default {
        name:'Son',
        data(){
            return {
                name:''
            }
        },
        props:['title','msg'],
        created(){
            this.$emit('handler',1);

            this.$bus.$on('click',(name)=>{
                this.name = name;
            })
        },
         computed:{
            //默认只有getter
            getCount(){
                return this.$store.state.count
            }
        }
    }
</script>

<style scoped>

</style>