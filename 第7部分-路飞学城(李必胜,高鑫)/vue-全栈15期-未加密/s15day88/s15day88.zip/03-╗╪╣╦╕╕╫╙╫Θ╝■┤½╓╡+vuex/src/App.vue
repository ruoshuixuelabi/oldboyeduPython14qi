<template>
  <div id="app">
    <div class="header">
      <ul>
       
      </ul>
    </div>
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App',
  data(){
    return {
     
    }
  }
}
</script>

<style>

</style>
