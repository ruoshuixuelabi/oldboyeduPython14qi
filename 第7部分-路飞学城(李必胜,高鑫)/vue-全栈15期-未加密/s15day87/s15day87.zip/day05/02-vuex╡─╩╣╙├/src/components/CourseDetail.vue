<template>
    <div>
        <p v-for = '(question) in questionList ' :key='question.id'>{{question.answer}}</p>
    </div>
</template>

<script>
    export default {
        name:"CourseDetail",
        created(){
            console.log(this.$route.params.courseId)
            this.$store.dispatch('course_questions',this.$route.params.courseId)
        },
        computed:{
            questionList(){
             
                return this.$store.state.questionList
            }
        }
    }
</script>

<style scoped>

</style>