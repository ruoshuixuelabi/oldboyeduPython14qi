<template>
    <div>
       我是首页
    </div>
</template>

<script>
    export default {
        name:'Home'
    }
</script>

<style scoped>

</style>