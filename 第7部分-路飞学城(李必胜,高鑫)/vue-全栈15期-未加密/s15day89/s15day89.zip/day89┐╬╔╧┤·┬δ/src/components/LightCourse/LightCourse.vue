<template>
    <div>
        我是轻课
    </div>
</template>

<script>
    export default {
        name:"LightCourse"
    }
</script>

<style scoped>

</style>