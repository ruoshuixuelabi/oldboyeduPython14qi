<template>
    <div>
        我是学位课程
    </div>
</template>

<script>
    export default {
        name:'Micro'
    }
</script>

<style scoped>

</style>